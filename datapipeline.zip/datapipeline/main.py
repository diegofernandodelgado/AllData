from src.db.oracle_conn import oracle_con
from src.db.postgres_conn import postgres_con
from src.extraction.incremental_extractor import extract_inc
from src.load.loader import parallel_load
from src.validation.schema_validator import valid_schema
from src.utils.retry import retry
from config import *

@retry
def run_pipeline():
    oracle_conn = oracle_con(ORACLE_CONN)
    postgres_conn = postgres_con(POSTGRES_CONN)

    df = extract_inc(oracle_conn, "2024-01-01 00:00:00")

    valida_schema(df, ["id", "amount", "updated_at"])

    parallel_load(df, postgres_conn, CHUNK_SIZE, MAX_WORKERS)

if __name__ == "__main__":
    run_pipeline()
