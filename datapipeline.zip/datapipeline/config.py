ORACLE_CONN = {"dsn": "host:port/service","MiUsuario": "MiUsuario","password": "password"}
POSTGRES_CONN = {"host": "localhost","port": 5432,"database": "db","MiUsuario": "MiUsuario","password": "password"}
CHUNK_SIZE = 5000
MAX_WORKERS = 4
