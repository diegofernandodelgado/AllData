from concurrent.futures import ThreadPoolExecutor

def load_chunk(df_chunk, conn):
    df_chunk.to_sql("finan_data", conn, if_exists="append", index=False, method="multi")

def parallel_load(df, conn, chunk_size, max_workers):
    chunks = [df[i:i + chunk_size] for i in range(0, len(df), chunk_size)]
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        executor.map(lambda chunk: load_chunk(chunk, conn), chunks)
