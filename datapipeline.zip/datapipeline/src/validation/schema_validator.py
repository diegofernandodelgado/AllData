def validate_schema(df, expected_schema):
    if set(df.columns) != set(expected_schema):
        raise ValueError("Schema mismatch")
    return True
