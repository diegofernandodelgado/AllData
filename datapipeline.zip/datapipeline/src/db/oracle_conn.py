import cx_Oracle
def oracle_con(config):
    return cx_Oracle.connect(user=config["user"],password=config["password"],dsn=config["dsn"])
