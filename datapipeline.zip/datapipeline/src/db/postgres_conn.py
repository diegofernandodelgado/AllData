import psycopg2
def postgres_con(config):
    return psycopg2.connect(**config)
