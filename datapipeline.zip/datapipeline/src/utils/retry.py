import time
def retry(func):
    def wrapper(*args, **kwargs):
        for _ in range(3):
            try:
                return func(*args, **kwargs)
            except Exception:
                time.sleep(5)
        raise Exception("Failed after retries")
    return wrapper
