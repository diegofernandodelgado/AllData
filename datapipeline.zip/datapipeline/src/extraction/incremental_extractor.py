import pandas as pd
def extract_inc(conn, last_timestamp):
    query = f"SELECT * FROM finan_data WHERE updated_at > TO_TIMESTAMP('{last_timestamp}', 'YYYY-MM-DD HH24:MI:SS')"
    return pd.read_sql(query, conn)
